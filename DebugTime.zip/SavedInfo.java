import java.io.Serializable;
import java.util.Arrays;

class SavedInfo implements Serializable{
   private static final long serialVersionUID = 1L;
   public boolean yPushedEvenTimes = true;
   public SavedInfo(){
   }
}