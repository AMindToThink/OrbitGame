class StringUtility
{
   /*
      public static boolean endsWith(String big, String possibleEnd)
   {
      int bigLength = big.length();
      int endLength = possibleEnd.length();
      return true;
   }
   */
}